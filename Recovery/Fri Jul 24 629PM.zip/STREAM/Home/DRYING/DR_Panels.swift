//
//  DR_Panels.swift
//  STREAM
//
//  Created by Danxd on 7/24/26.
//

import SwiftUI
import SwiftData

struct PanelDeviceStatus: Codable, Identifiable {
    var id: String { dhid }
    var dhid: String
    var device_owner: String?
    var device_model: String?
    var deivice_id: String?
}


struct DryingPanel: Codable, Identifiable {
    var id: String { dmhead.dhid }

    let dmhead: DryingHeader
    let dmrows: [DryingMonitoring]
}

struct DryingHeader: Codable, Identifiable {
    var id: String { dhid }
    let dhid: String
    let rhid: String
    let bin_id: String
    let initial_mc: String
    let drying_start: String
    let date: String
    let device_owner: String?
    let device_model: String?
    let deivice_id: String?
    let est_drying_end: String
    let reversal: String
    let blower: String
    let hybrid_code: String
    let statis: String
}

struct DryingMonitoring: Codable, Identifiable {
    var id: String { dmrid }

    let dmrid: String
    let dhid: String
    let noh: String
    let date: String
    let time: String
    let upper: String
    let lower: String
    let boiler: String
    let mc: String
    let status: String
}


struct DR_Panels: View {
    
    @Environment(\.modelContext) private var context
    
    @State private var localdrheader: [tbl_drying_header] = []
    @State private var paneldevicestatus: [PanelDeviceStatus] = []
    
    @State private var dryingPanels: [DryingPanel] = []
    
    var body: some View {
        NavigationStack {
            if dryingPanels.isEmpty {
                Text("No Data")
            } else {
                List(dryingPanels) { item in
                    HStack {
                        HStack {
                            ZStack {
                                Circle()
                                    .fill(Color.orange.opacity(0.15))
                                    .frame(width: 58, height: 58)
                                
                                Image(systemName: "flame.fill")
                                    .font(.title2)
                                    .foregroundStyle(.orange)
                            }
                            VStack(alignment: .leading) {
                                Text("Bin \(item.dmhead.bin_id)")
                                    .font(.title)
                                    .bold()
                                Text("ID: \(item.dmhead.dhid)")
                                    .foregroundStyle(Color.secondary)
                            }
                        }
                        .padding()
                        .frame(width: 200)
                        
                        Divider()
                        VStack(alignment: .leading) {
                            HStack {
                                HStack {
                                    ZStack {
                                        Circle()
                                            .fill(Color.blue.opacity(0.15))
                                            .frame(width: 45, height: 45)
                                        Image(systemName: "drop.fill")
                                            .font(.title2)
                                            .foregroundStyle(.blue)
                                    }
                                    VStack(alignment: .leading) {
                                        Text("\(item.dmhead.initial_mc)")
                                            .bold()
                                        Text("Inital MC")
                                            .foregroundStyle(Color.secondary)
                                    }
                                }
                                .padding()
                                
                                HStack {
                                    ZStack {
                                        Circle()
                                            .fill(Color.indigo.opacity(0.15))
                                            .frame(width: 45, height: 45)
                                        Image(systemName: "arrow.up.arrow.down")
                                            .font(.title2)
                                            .foregroundStyle(.indigo)
                                    }
                                    HStack {
                                        VStack(alignment: .leading) {
                                            Text("34.3")
                                                .bold()
                                            Text("Top")
                                                .foregroundStyle(Color.secondary)
                                        }
                                        Divider()
                                        VStack(alignment: .leading) {
                                            Text("34.3")
                                                .bold()
                                            Text("Bot")
                                                .foregroundStyle(Color.secondary)
                                        }
                                    }
                                    
                                }
                                .padding()
                                
                                HStack {
                                    ZStack {
                                        Circle()
                                            .fill(Color.green.opacity(0.15))
                                            .frame(width: 45, height: 45)
                                        Image(systemName: "clock")
                                            .font(.title2)
                                            .foregroundStyle(.green)
                                    }
                                    VStack(alignment: .leading) {
                                        Text("34.3")
                                            .bold()
                                        Text("Timer")
                                            .foregroundStyle(Color.secondary)
                                    }
                                }
                                .padding()
                                  
                                HStack {
                                    ZStack {
                                        Circle()
                                            .fill(Color.orange.opacity(0.15))
                                            .frame(width: 58, height: 58)
                                        
                                        Image(systemName: "flame.fill")
                                            .font(.title2)
                                            .foregroundStyle(.orange)
                                    }
                                }
                                .padding()
                            }
                            HStack {
                                
                                if item.dmhead.deivice_id == nil ||
                                   item.dmhead.device_model == nil ||
                                   item.dmhead.device_owner == nil
                                {
                                    Text("The bin is free to migrate")
                                        .foregroundStyle(Color.green)
                                        .padding(.horizontal, 3)
                                        .background(Color.green.opacity(0.15))
                                        .cornerRadius(50)
                                } else {
                                    Text("Device Name: \(item.dmhead.device_owner ?? "")")
                                        .foregroundStyle(Color.orange)
                                        .padding(.horizontal, 3)
                                        .background(Color.orange.opacity(0.15))
                                        .cornerRadius(50)
                                    Text("Model: \(item.dmhead.device_model ?? "")")
                                        .foregroundStyle(Color.orange)
                                        .padding(.horizontal, 3)
                                        .background(Color.orange.opacity(0.15))
                                        .cornerRadius(50)
                                    Text("Id: \(item.dmhead.deivice_id ?? "")")
                                        .foregroundStyle(Color.orange)
                                        .padding(.horizontal, 3)
                                        .background(Color.orange.opacity(0.15))
                                        .cornerRadius(50)
                                }
                            }
                            .font(.footnote)
                            .foregroundStyle(Color.secondary)
                            .padding(.leading)
                        }
                        
                        
                    }
                    .swipeActions(edge: .trailing) {
                        
                        if item.dmhead.deivice_id == nil {
                            Button(action: {
                                migrateData(dhid: item.dmhead.dhid)
    //                            print("Migrated: \(item.dhid)")
                                saveDataLocal(dhid: item.dmhead.dhid)
                            }) {
                                Image(systemName: "icloud.and.arrow.down.fill")
                                    .tint(Color.blue)
                            }
                        } else {
                            if item.dmhead.deivice_id == UIDevice.current.identifierForVendor?.uuidString {
                                
                                Button(action: {
                                    migrateData(dhid: item.dmhead.dhid)
        //                            print("Migrated: \(item.dhid)")
                                    saveDataLocal(dhid: item.dmhead.dhid)
                                }) {
                                    Image(systemName: "pencil.circle.fill")
                                        .tint(Color.blue)
                                }
                                
                            } else {
                                Button(action: {
                                    migrateData(dhid: item.dmhead.dhid)
        //                            print("Migrated: \(item.dhid)")
                                    saveDataLocal(dhid: item.dmhead.dhid)
                                }) {
                                    Image(systemName: "x.circle")
                                        .tint(Color.red)
                                }
                            }
                        }
                        
                        
                        
                    }
                }
            }
        }
        .onAppear() {
            loadData()
            loadDrDataOnine()
        }
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button(action: {
                    
                }) {
                    Image(systemName: "flame.circle.fill")
                        .tint(Color.orange)
                }
            }
        }
    }
    
    func migrateData(dhid: String) {
        
        let devicename = UIDevice.current.name
        let deviceid = UIDevice.current.identifierForVendor?.uuidString ?? ""
        let devicemodel = UIDevice.current.model
        
        guard let url = URL(string: "https://ops.stellarseedscorp.org/App/DR/migratedata.php") else { return }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")

        let body = [
            "dhid": dhid,
            "devicename": devicename,
            "deviceid": deviceid,
            "devicemodel": devicemodel
        ]

        request.httpBody = try? JSONSerialization.data(withJSONObject: body)

        URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print(error.localizedDescription)
                return
            }

            if let data = data {
                loadData()
                loadDrDataOnine()
//                print(String(data: data, encoding: .utf8) ?? "")
                
            }
        }.resume()
    }
    
    func saveDataLocal(dhid: String) {
        
        let descriptor = FetchDescriptor<tbl_drying_header>(
            predicate: #Predicate { $0.dhid == dhid }
        )
        
        let descriptorrows = FetchDescriptor<tbl_drmonitoring_rows>(
            predicate: #Predicate { $0.dhid == dhid }
        )

        do {
            let result = try context.fetch(descriptor)

            if let header = result.first {
                context.delete(header)
                
                let resultrows = try context.fetch(descriptorrows)
                
                for row in resultrows {
                    context.delete(row)
                }
                try context.save()
                print("Deleted DB")
//                print("Existed! \(header.dhid)")
                
                
            } else {
                
               if  let getHeaderOnline = dryingPanels.first(where: { $0.dmhead.dhid == dhid }) {
                   
                   let insertHeader = tbl_drying_header(
                    dhid: getHeaderOnline.dmhead.dhid,
                    rhid: getHeaderOnline.dmhead.rhid,
                    initial_mc: getHeaderOnline.dmhead.initial_mc,
                    drying_start: getHeaderOnline.dmhead.drying_start,
                    est_drying_end: getHeaderOnline.dmhead.est_drying_end,
                    reversal: getHeaderOnline.dmhead.reversal,
                    blower: getHeaderOnline.dmhead.blower,
                    bin_id: getHeaderOnline.dmhead.bin_id,
                    hybrid: getHeaderOnline.dmhead.hybrid_code,
                    statis: getHeaderOnline.dmhead.statis)
                   
                   do {
                       context.insert(insertHeader)
                       
                       for rows in getHeaderOnline.dmrows {
                           
                           let dmrows = tbl_drmonitoring_rows(
                            dmid: rows.dmrid,
                            dhid: rows.dhid,
                            noh: rows.noh,
                            date: rows.date,
                            time: rows.time,
                            upper: rows.upper,
                            lower: rows.lower,
                            boiler: rows.boiler,
                            mc: rows.mc,
                            status: rows.status)
                           
                           context.insert(dmrows)
                           
                       }
                       
                       try context.save()
                       print("Local Data Saved!")
                       
                   } catch {
                       print("Local Dryer Header Error!")
                   }
                   
                }
                
                
                
            }

        } catch {
            print("Error: \(error)")
        }
        
        
    }
    
    func loadData() {
        let descriptor = FetchDescriptor<tbl_drying_header>()
        
        do {
            localdrheader = try context.fetch(descriptor)
        } catch {
            print("Error fetching")
        }
    }
    
    func loadDrDataOnine() {
        
        guard let url = URL(string: "https://ops.stellarseedscorp.org/App/DR/get_current_drying.php") else { return }
        
        URLSession.shared.dataTask(with: url) { data, response, error in

            guard let data = data else { return }

            do {
                let result = try JSONDecoder().decode([DryingPanel].self, from: data)
//                print("DS: \(result)")
                dryingPanels = result

            } catch {
                print("Errorsx")
            }

        }.resume()
        
    }
}

#Preview {
    DR_Panels()
}
