//
//  DR_CurrentPanels.swift
//  STREAM
//
//  Created by Danxd on 7/24/26.
//

import SwiftUI
import SwiftData

struct DR_CurrentPanels: View {

    var body: some View {
        NavigationStack {
            
        }
    }
    
}

#Preview {
    DR_CurrentPanels()
}
