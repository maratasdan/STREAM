//
//  P_Home.swift
//  STREAM APP
//
//  Created by Danxd on 7/21/26.
//

import SwiftUI

struct P_Home: View {
    
    @State private var goHome: Bool = false
    
    var body: some View {
        NavigationStack {
            List {
                NavigationLink(destination: P_RMFApprovalList()) {
                    HStack {
                        Image(systemName: "checklist")
                            .font(.system(size:30))
                            .foregroundColor(Color.green)
                        VStack(alignment: .leading) {
                            Text("Approvals")
                                .font(.system(size:18))
                                .bold()
                                .foregroundColor(Color.green)
                            Text("List of all approvals")
                                .font(.callout)
                        }
                    }
                }
                
                NavigationLink(destination: P_ListOfLCC()) {
                    HStack {
                        Image(systemName: "list.bullet.clipboard")
                            .font(.system(size:30))
                            .foregroundColor(Color.green)
                        VStack(alignment: .leading) {
                            Text("Line Cleaning Checklist")
                                .font(.system(size:18))
                                .bold()
                                .foregroundColor(Color.green)
                            Text("LCC List and QR Code ")
                                .font(.callout)
                        }
                    }
                }
                
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationDestination(isPresented: $goHome) {
            RCV_Home()
        }
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button {
                    goHome = true
                } label: {
                    Image(systemName: "house.circle.fill")
                }
            }
        }
    }
}

#Preview {
    P_Home()
}
