//
//  STREAMApp.swift
//  STREAM
//
//  Created by Danxd on 7/6/26.
//

import SwiftUI
import SwiftData

@main
struct STREAMApp: App {
    var body: some Scene {
        WindowGroup {
//            RCV_Home()
            DR_Panel()
        }
        .modelContainer(for:[
            tbl_lcc.self,
            tbl_drmonitoring_rows.self,
            tbl_drying_header.self
        ])
    }
}
